<h2>FinGPT</h2>
<h3>How to run the Final Model</h3>
<li>Put every HTML, CSS and Javascript file into the template folder and in single location.</li>
<li>Check that whether "classes.pkl", "intents.json", "chatbot_model.h5", "words.pkl", "app.py" is present or not in the root directory.
<li>Run the app.py file to start the model.</li>

<h3>Questions that can be asked to our Chatbot!</h3>
<ol>Greetings and Goodbye messages!</ol>
<ol>Basic personal Details of our AI</ol>
<ol>Basic Questions related to Stocks and Stock Market</ol>
<ol>Basic Questions related to Bonds in investments.</ol>
<ol>Basic Questions related to Mutual Funds.</ol>
